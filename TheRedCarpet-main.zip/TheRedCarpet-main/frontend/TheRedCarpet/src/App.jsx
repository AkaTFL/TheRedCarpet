import "./App.css";
import Register from "./components/register/register.jsx";

function App() {
  return (
    <>
      <Register />
    </>
  );
}

export default App;
